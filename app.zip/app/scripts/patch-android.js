const fs=require('fs'),path=require('path');
const RES='android/app/src/main/res',MAN='android/app/src/main/AndroidManifest.xml';
function copyDir(s,d){fs.mkdirSync(d,{recursive:true});for(const e of fs.readdirSync(s,{withFileTypes:true})){const a=path.join(s,e.name),b=path.join(d,e.name);e.isDirectory()?copyDir(a,b):fs.copyFileSync(a,b)}}
copyDir('native-assets/res',RES);
(function walk(d){for(const e of fs.readdirSync(d,{withFileTypes:true})){const p=path.join(d,e.name);if(e.isDirectory())walk(p);else if(e.name==='splash.png')fs.copyFileSync('native-assets/splash.png',p)}})(RES);
let m=fs.readFileSync(MAN,'utf8');
function add(line,key){if(!m.includes(key))m=m.replace('</manifest>','    '+line+'\n</manifest>')}
['POST_NOTIFICATIONS','USE_EXACT_ALARM','RECEIVE_BOOT_COMPLETED','VIBRATE','ACCESS_COARSE_LOCATION','ACCESS_FINE_LOCATION'].forEach(n=>add('<uses-permission android:name="android.permission.'+n+'" />','android.permission.'+n));
add('<uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" android:maxSdkVersion="32" />','android.permission.SCHEDULE_EXACT_ALARM');
fs.writeFileSync(MAN,m);console.log('android project patched');
