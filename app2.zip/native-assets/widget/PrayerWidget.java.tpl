package __PKG__;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.SystemClock;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class PrayerWidget extends AppWidgetProvider {
    private static final String TICK = "__PKG__.WIDGET_TICK";

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        RemoteViews v = build(c);
        for (int id : ids) m.updateAppWidget(id, v);
        schedule(c);
    }

    @Override
    public void onEnabled(Context c) {
        schedule(c);
    }

    @Override
    public void onReceive(Context c, Intent i) {
        super.onReceive(c, i);
        if (i != null && TICK.equals(i.getAction())) {
            AppWidgetManager m = AppWidgetManager.getInstance(c);
            int[] ids = m.getAppWidgetIds(new ComponentName(c, PrayerWidget.class));
            if (ids != null && ids.length > 0) {
                RemoteViews v = build(c);
                for (int id : ids) m.updateAppWidget(id, v);
            }
            schedule(c);
        }
    }

    private static JSONObject data(Context c) {
        try {
            SharedPreferences sp = c.getSharedPreferences("CapacitorStorage", Context.MODE_PRIVATE);
            String raw = sp.getString("widget_times", null);
            return raw == null ? null : new JSONObject(raw);
        } catch (Exception e) {
            return null;
        }
    }

    private static int nextIndex(JSONObject o, long now) {
        try {
            JSONArray a = o.getJSONArray("t");
            for (int k = 0; k < a.length(); k++) {
                if (a.getJSONArray(k).getLong(1) > now) return k;
            }
        } catch (Exception e) { }
        return -1;
    }

    private static RemoteViews build(Context c) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_prayer);
        try {
            Intent li = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
            if (li != null) {
                PendingIntent pi = PendingIntent.getActivity(c, 0, li,
                        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
                v.setOnClickPendingIntent(R.id.w_root, pi);
            }
        } catch (Exception e) { }

        JSONObject o = data(c);
        long now = System.currentTimeMillis();
        int k = o == null ? -1 : nextIndex(o, now);
        if (k < 0) {
            String msg = "افتح التطبيق لتحديث المواقيت";
            try { if (o != null && o.has("open")) msg = o.getString("open"); } catch (Exception e) { }
            v.setTextViewText(R.id.w_title, "رفيق المسلم");
            v.setTextViewText(R.id.w_name, "");
            v.setTextViewText(R.id.w_time, msg);
            v.setViewVisibility(R.id.w_cd, android.view.View.GONE);
            v.setTextViewText(R.id.w_loc, "");
            return v;
        }
        try {
            JSONArray p = o.getJSONArray("t").getJSONArray(k);
            long ms = p.getLong(1);
            v.setTextViewText(R.id.w_title, o.optString("title", "الصلاة القادمة"));
            v.setTextViewText(R.id.w_name, p.getString(0));
            v.setTextViewText(R.id.w_time, new SimpleDateFormat("h:mm a", Locale.getDefault()).format(new Date(ms)));
            v.setTextViewText(R.id.w_loc, o.optString("loc", ""));
            v.setViewVisibility(R.id.w_cd, android.view.View.VISIBLE);
            v.setChronometer(R.id.w_cd, SystemClock.elapsedRealtime() + (ms - now), null, true);
            if (Build.VERSION.SDK_INT >= 24) v.setChronometerCountDown(R.id.w_cd, true);
        } catch (Exception e) {
            v.setTextViewText(R.id.w_time, "—");
        }
        return v;
    }

    private static void schedule(Context c) {
        try {
            JSONObject o = data(c);
            long now = System.currentTimeMillis();
            int k = o == null ? -1 : nextIndex(o, now);
            long at = (k < 0) ? now + 30L * 60 * 1000 : o.getJSONArray("t").getJSONArray(k).getLong(1) + 1500;
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            Intent in = new Intent(c, PrayerWidget.class).setAction(TICK);
            PendingIntent pi = PendingIntent.getBroadcast(c, 77, in,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            if (am == null) return;
            if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC, at, pi);
            else am.set(AlarmManager.RTC, at, pi);
        } catch (Exception e) { }
    }
}
