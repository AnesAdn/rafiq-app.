const fs=require('fs'),path=require('path');
const RES='android/app/src/main/res',MAN='android/app/src/main/AndroidManifest.xml';
function copyDir(s,d){fs.mkdirSync(d,{recursive:true});for(const e of fs.readdirSync(s,{withFileTypes:true})){const a=path.join(s,e.name),b=path.join(d,e.name);e.isDirectory()?copyDir(a,b):fs.copyFileSync(a,b)}}
copyDir('native-assets/res',RES);
(function walk(d){for(const e of fs.readdirSync(d,{withFileTypes:true})){const p=path.join(d,e.name);if(e.isDirectory())walk(p);else if(e.name==='splash.png')fs.copyFileSync('native-assets/splash.png',p)}})(RES);
let m=fs.readFileSync(MAN,'utf8');
function add(line,key){if(!m.includes(key))m=m.replace('</manifest>','    '+line+'\n</manifest>')}
['POST_NOTIFICATIONS','USE_EXACT_ALARM','RECEIVE_BOOT_COMPLETED','VIBRATE','ACCESS_COARSE_LOCATION','ACCESS_FINE_LOCATION'].forEach(n=>add('<uses-permission android:name="android.permission.'+n+'" />','android.permission.'+n));
add('<uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" android:maxSdkVersion="32" />','android.permission.SCHEDULE_EXACT_ALARM');
const ADMOB_APP_ID='ca-app-pub-6630383601701998~1024264367';
if(!m.includes('com.google.android.gms.ads.APPLICATION_ID')){m=m.replace('</application>','        <meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="'+ADMOB_APP_ID+'"/>\n    </application>')}
['INTERNET','ACCESS_NETWORK_STATE','AD_ID'].forEach(n=>add('<uses-permission android:name="'+(n==='AD_ID'?'com.google.android.gms.permission.AD_ID':'android.permission.'+n)+'" />',n==='AD_ID'?'permission.AD_ID':'android.permission.'+n));
fs.writeFileSync(MAN,m);
const VG='android/variables.gradle';
if(fs.existsSync(VG)){let v=fs.readFileSync(VG,'utf8');v=v.replace(/minSdkVersion\s*=\s*\d+/,'minSdkVersion = 23');fs.writeFileSync(VG,v)}
const GR='android/app/build.gradle';
if(fs.existsSync(GR)){let g=fs.readFileSync(GR,'utf8');g=g.replace(/versionCode\s+\d+/,'versionCode 6').replace(/versionName\s+"[^"]*"/,'versionName "4.2"');fs.writeFileSync(GR,g)}console.log('android project patched');
