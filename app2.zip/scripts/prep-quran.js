const fs=require('fs');
const raw=JSON.parse(fs.readFileSync('quran-raw.json','utf8'));
const surahs=raw.data.surahs;
const skel=s=>s.replace(/[\u0640\u064B-\u065F\u0670\u06D6-\u06ED]/g,'').replace(/[\u0671\u0623\u0625\u0622]/g,'ا');
const BIS='بسم الله الرحمن الرحيم';
const out=[];let stripped=0;
for(const su of surahs)for(const a of su.ayahs){
  let t=a.text;
  if(a.numberInSurah===1&&su.number!==1&&su.number!==9){
    const w=t.split(/\s+/);
    if(w.length>4&&skel(w.slice(0,4).join(' '))===BIS){t=w.slice(4).join(' ');stripped++}
  }
  out.push([su.number,a.numberInSurah,a.page,a.juz,t,a.sajda?1:0]);
}
if(surahs.length!==114||out.length!==6236)throw new Error('unexpected data: '+surahs.length+' surahs, '+out.length+' ayahs');
if(out.some(r=>!(r[2]>=1&&r[2]<=604)))throw new Error('bad page numbers');
fs.writeFileSync('www/quran-data.js','window.QURAN={a:'+JSON.stringify(out)+'};');
console.log('Quran data ready:',out.length,'ayahs; bismillah separated from',stripped,'surahs');
