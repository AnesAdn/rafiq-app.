const fs=require('fs'),path=require('path');
const RES='android/app/src/main/res',MAN='android/app/src/main/AndroidManifest.xml';
function copyDir(s,d){fs.mkdirSync(d,{recursive:true});for(const e of fs.readdirSync(s,{withFileTypes:true})){const a=path.join(s,e.name),b=path.join(d,e.name);e.isDirectory()?copyDir(a,b):fs.copyFileSync(a,b)}}
copyDir('native-assets/res',RES);
(function walk(d){for(const e of fs.readdirSync(d,{withFileTypes:true})){const p=path.join(d,e.name);if(e.isDirectory())walk(p);else if(e.name==='splash.png')fs.copyFileSync('native-assets/splash.png',p)}})(RES);
let m=fs.readFileSync(MAN,'utf8');
function add(line,key){if(!m.includes(key))m=m.replace('</manifest>','    '+line+'\n</manifest>')}
['POST_NOTIFICATIONS','USE_EXACT_ALARM','RECEIVE_BOOT_COMPLETED','VIBRATE','ACCESS_COARSE_LOCATION','ACCESS_FINE_LOCATION'].forEach(n=>add('<uses-permission android:name="android.permission.'+n+'" />','android.permission.'+n));
add('<uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" android:maxSdkVersion="32" />','android.permission.SCHEDULE_EXACT_ALARM');
add('<uses-permission android:name="com.google.android.gms.permission.AD_ID" />','com.google.android.gms.permission.AD_ID');
if(!m.includes('com.google.android.gms.ads.APPLICATION_ID')){m=m.replace(/<application[^>]*>/,function(t){return t+'\n        <meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="ca-app-pub-6630383601701998~1024264367"/>'})}
fs.writeFileSync(MAN,m);

/* ---- home-screen widget (next prayer + live countdown) ---- */
try{
const pkg=JSON.parse(fs.readFileSync('capacitor.config.json','utf8')).appId;
const WS='native-assets/widget',MAINDIR='android/app/src/main';
fs.mkdirSync(MAINDIR+'/java/'+pkg.split('.').join('/'),{recursive:true});
fs.writeFileSync(MAINDIR+'/java/'+pkg.split('.').join('/')+'/PrayerWidget.java',fs.readFileSync(WS+'/PrayerWidget.java.tpl','utf8').split('__PKG__').join(pkg));
['layout','xml','drawable','values'].forEach(d=>fs.mkdirSync(MAINDIR+'/res/'+d,{recursive:true}));
fs.copyFileSync(WS+'/widget_prayer.xml',MAINDIR+'/res/layout/widget_prayer.xml');
fs.copyFileSync(WS+'/prayer_widget_info.xml',MAINDIR+'/res/xml/prayer_widget_info.xml');
fs.copyFileSync(WS+'/widget_bg.xml',MAINDIR+'/res/drawable/widget_bg.xml');
fs.copyFileSync(WS+'/widget_strings.xml',MAINDIR+'/res/values/widget_strings.xml');
let mm=fs.readFileSync(MAN,'utf8');
if(!mm.includes('PrayerWidget')){mm=mm.replace('</application>','        <receiver android:name="'+pkg+'.PrayerWidget" android:exported="true" android:label="الصلاة القادمة"><intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE"/></intent-filter><meta-data android:name="android.appwidget.provider" android:resource="@xml/prayer_widget_info"/></receiver>\n    </application>')}
fs.writeFileSync(MAN,mm);
console.log('widget added for',pkg);
}catch(e){console.log('widget skipped:',e.message)}
const GR='android/app/build.gradle';
if(fs.existsSync(GR)){let g=fs.readFileSync(GR,'utf8');g=g.replace(/versionCode\s+\d+/,'versionCode 11').replace(/versionName\s+"[^"]*"/,'versionName "4.6"');fs.writeFileSync(GR,g)}console.log('android project patched');
